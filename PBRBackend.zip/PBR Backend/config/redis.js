const { createClient } = require("redis");

// Use the Redis container name as the host (Docker internal DNS)
const redisClient = createClient({
  socket: {
    host: process.env.REDIS_HOST || 'redis', // fallback to 'redis'
    port: 6379,
  },
});

redisClient.on("error", (err) => console.error("❌ Redis Client Error:", err));

const connectRedis = async () => {
  await redisClient.connect();
  console.log("✅ Redis Connected");
};

module.exports = { redisClient, connectRedis };

const { redisClient } = require("../config/redis");

const acquireLock = async (key, ttl = 5000) => {
  const lockKey = `lock:${key}`;
  const lockValue = Date.now().toString();

  const result = await redisClient.set(lockKey, lockValue, {
    NX: true, // Only set if key does not exist
    PX: ttl,  // Expire after TTL (ms)
  });

  if (result === null) {
    // Lock already exists
    return false;
  }

  return lockValue; 
};

const releaseLock = async (key, lockValue) => {
  const lockKey = `lock:${key}`;
  const currentValue = await redisClient.get(lockKey);

  if (currentValue === lockValue) {
    await redisClient.del(lockKey); 
    return true;
  }

  return false;
};

module.exports = { acquireLock, releaseLock };

const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendAlertEmail = async (contract) => {
  const { contractId, deviceCount, batteriesShipped, threshold } = contract;
    console.log("printing creds")
    console.log(process.env.EMAIL_USER)
    console.log(process.env.EMAIL_PASS)
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: "jaga1234officil@gmail.com", 
    subject: `⚠ PBR Battery Shipment Limit Reached (Contract: ${contractId})`,
    html: `
      <p><b>The battery shipment limit has been reached.</b></p>
      <ul>
        <li><b>Contract:</b> ${contractId}</li>
        <li><b>Devices Under Contract:</b> ${deviceCount}</li>
        <li><b>Batteries Shipped:</b> ${batteriesShipped}</li>
        <li><b>Threshold:</b> ${threshold}</li>
      </ul>
      <p>Further shipments are <b>BLOCKED</b> until manual review.</p>
    `,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("🚨 Alert email sent:", info.response);
    return true;
  } catch (err) {
    console.error("❌ Email failed to send:", err.message);
    return false;
  }
};

module.exports = { sendAlertEmail };

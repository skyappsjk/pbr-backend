const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const { connectRedis } = require("./config/redis");
const { createContract } = require("./controllers/contractController");
const contractRoutes = require("./routes/contractRoutes");
const shipmentRoutes = require("./routes/shipmentRoutes");
const http = require("http");
const cors = require("cors");
const path = require("path");

dotenv.config();
connectDB();

const app = express();   //creating express app
app.use(express.json());  // tells express to convert the incoming json to request.body
app.use(cors({origin: "http://56.228.31.234"}));




const server = http.createServer(app);

// 👇 Initialize socket separately
const socket = require("./sockets/socket");
const io = socket.init(server);

app.use(express.static(path.join(__dirname, "public", "dist")));

app.use("/api/auth", authRoutes);
app.use("/api/contract", contractRoutes);
app.use("/api/shipment", shipmentRoutes);


// app.get("/", (req, res) => {
//   res.sendFile(path.join(__dirname, "public", "dist", "index.html"));
// });

const PORT = process.env.PORT || 5000;
server.listen(PORT, async () => {
  await connectRedis();
  
  console.log(`Server running on port ${PORT}`)
});
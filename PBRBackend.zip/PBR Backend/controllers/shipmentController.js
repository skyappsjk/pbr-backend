const Contract = require("../models/Contract");
const Shipment = require("../models/Shipment");
const { acquireLock, releaseLock } = require("../services/lockService");
const { sendAlertEmail } = require("../services/emailService");
const { getIO } = require("../sockets/socket");


const createShipment = async (req, res) => {
  const { contractId, batteriesShipped, initiatedBy } = req.body;

  if (!contractId || !batteriesShipped || batteriesShipped <= 0) {
    return res.status(400).json({ message: "Invalid input" });
  }

  const lockKey = `contract:${contractId}`;
  const lockValue = await acquireLock(lockKey);

  if (!lockValue) {
    return res.status(429).json({ message: "Another shipment is being processed. Try again." });
  }

  try {
    const contract = await Contract.findOne({ contractId });

    if (!contract) {
      return res.status(404).json({ message: "Contract not found" });
    }

    const totalAfterShipment = contract.batteriesShipped + batteriesShipped;

    // BLOCKED shipment logic
    if (totalAfterShipment > contract.threshold || contract.isLocked) {
      contract.isLocked = true;
      contract.lastUpdated = new Date();
      await contract.save();

      const blockedShipment = await Shipment.create({
        shipmentId: `SHP-${Date.now()}`,
        contractId,
        batteriesShipped,
        status: "BLOCKED",
        initiatedBy,
      });
      const isAlertSent = await sendAlertEmail(contract);
      if (isAlertSent){
        contract.notificationsSent.push({
          email: "jaga1234official@gmail.com",
          timestamp: new Date(),
          message: `Shipment blocked for ${contractId}`
        });
        await contract.save();
      }

      getIO().emit("shipmentUpdate", { type: "blocked", shipment: blockedShipment, contract: contract });
      return res.status(200).json({ message: "Shipment blocked", shipment: blockedShipment });
    }
    
    // APPROVED shipment logic
    const approvedShipment = await Shipment.create({
      shipmentId: `SHP-${Date.now()}`,
      contractId,
      batteriesShipped,
      status: "APPROVED",
      initiatedBy,
    });
    
    contract.batteriesShipped += batteriesShipped;
    contract.lastUpdated = new Date();
    await contract.save();

    getIO().emit("shipmentUpdate", { type: "approved", shipment: approvedShipment, contract: contract });

    res.status(201).json({ message: "Shipment approved", shipment: approvedShipment });
  } catch (err) {
    console.error("Shipment creation failed:", err);
    res.status(500).json({ message: "Server error" });
  } finally {
    await releaseLock(lockKey, lockValue);
  }
};


const getShipments = async (req, res) => {
  try {
    const { contractId, status } = req.query;

    const filter = {};
    if (contractId) filter.contractId = contractId;
    if (status) filter.status = status;

    const shipments = await Shipment.find(filter).sort({ timestamp: -1 });

    res.status(200).json(shipments);
  } catch (err) {
    console.error("Get shipments failed:", err);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = { createShipment, getShipments };
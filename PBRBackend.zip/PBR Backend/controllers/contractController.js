const Contract = require("../models/Contract");
const { getIO } = require("../sockets/socket");

const createContract = async (req, res) => {
    console.info("running create contract")
    try {
        const { contractId, deviceCount } = req.body;
        
        if (!contractId || !deviceCount) {
            return res.status(400).json({ message: "Missing required fields" });
        }
        
        const threshold = deviceCount * 1.2;
        
        const existing = await Contract.findOne({ contractId });
        if (existing) {
            return res.status(409).json({ message: "Contract already exists" });
        }

    const newContract = await Contract.create({
        contractId,
        deviceCount,
        threshold,
        batteriesShipped: 0,
        isLocked: false,
        lastUpdated: new Date(),
        notificationsSent: [],
    });
    
    res.status(201).json(newContract);
} catch (err) {
    console.error("Create contract error:", err);
    res.status(500).json({ message: "Server error" });
}
};


const viewContracts = async (req, res) => {
    console.info("runninc view contract")
    try {
    const contracts = await Contract.find().sort({ lastUpdated: -1 });
    res.status(200).json(contracts);
  } catch (err) {
    console.error("Error fetching contracts:", err);
    res.status(500).json({ message: "Server error" });
  }
}


const unlockContract = async (req, res) => {
  const { id: contractId } = req.params;

  try {
    const contract = await Contract.findOne({ contractId });

    if (!contract) {
      return res.status(404).json({ message: "Contract not found" });
    }

    if (!contract.isLocked) {
      return res.status(400).json({ message: "Contract is already unlocked" });
    }

    contract.isLocked = false;
    contract.lastUpdated = new Date();
    await contract.save();

    getIO().emit("contractUpdate", {
      contractId: contract.contractId,
      isLocked: false,
    });

    res.status(200).json({ message: "Contract unlocked", contract });
  } catch (err) {
    console.error("Unlock failed:", err);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = { createContract, viewContracts, unlockContract };

const mongoose = require("mongoose");

const shipmentSchema = new mongoose.Schema({
  shipmentId: { type: String, required: true, unique: true },
  contractId: { type: String, required: true },
  batteriesShipped: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now },
  status: {
    type: String,
    enum: ["APPROVED", "BLOCKED", "PENDING"],
    default: "PENDING",
  },
  initiatedBy: { type: String }, 
});

module.exports = mongoose.model("Shipment", shipmentSchema);

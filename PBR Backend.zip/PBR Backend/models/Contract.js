const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema({
  email: String,
  timestamp: Date,
  message: String,
});

const contractSchema = new mongoose.Schema({
  contractId: { type: String, required: true, unique: true },
  deviceCount: { type: Number, required: true },
  batteriesShipped: { type: Number, default: 0 },
  threshold: { type: Number, required: true },
  isLocked: { type: Boolean, default: false },
  lastUpdated: { type: Date, default: Date.now },
  notificationsSent: [notificationSchema],
});

module.exports = mongoose.model("Contract", contractSchema);

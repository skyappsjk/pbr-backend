const express = require("express");
const router = express.Router();
const { protect, adminOnly } = require("../middleware/authMiddleware");
const { createContract, viewContracts, unlockContract } = require("../controllers/contractController");

router.post("/create", protect, adminOnly, createContract);
router.get("/view", protect, viewContracts);
router.post("/:id/unlock", protect, adminOnly, unlockContract);

module.exports = router;

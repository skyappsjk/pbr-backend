const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { createShipment, getShipments } = require("../controllers/shipmentController");

router.post("/create", protect, createShipment);
router.get("/", protect, getShipments);

module.exports = router;
